Creative Commons Attribution-NonCommercial 4.0 International Public License

By exercising the Licensed Rights (defined below), You accept and agree to be bound by the terms and conditions of this Creative Commons Attribution-NonCommercial 4.0 International Public License ("Public License").

## License Summary

- You are free to:
  - **Share** — copy and redistribute the material in any medium or format
  - **Adapt** — remix, transform, and build upon the material

- Under the following terms:
  - **Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made.
  - **NonCommercial** — You may not use the material for commercial purposes.

## Additional Terms

- No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

## Notices

You do not have to comply with the license for elements of the material in the public domain or where your use is permitted by an applicable exception or limitation.

## Disclaimer

The license is provided “as-is” and without warranties of any kind. 

For full legal terms, see: [https://creativecommons.org/licenses/by-nc/4.0/legalcode](https://creativecommons.org/licenses/by-nc/4.0/legalcode)

---

© 2025 Richard Barnes  
This work is licensed under a [Creative Commons Attribution-NonCommercial 4.0 International License](https://creativecommons.org/licenses/by-nc/4.0/).
