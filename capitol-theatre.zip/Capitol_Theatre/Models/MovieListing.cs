﻿using Capitol_Theatre.Data;

namespace Capitol_Theatre.Models
{
    public class MovieListing
    {
        public Movie Movie { get; set; } = null!;
        public string Status { get; set; } = "";
    }
}
